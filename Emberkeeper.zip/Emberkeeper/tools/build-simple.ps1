# 守烬人 Mod —— 精简版构建（Windows / PowerShell）
#
# 只需要一个 dll，不需要 Godot、不需要导出 pck。
# 角色美术沿用原版（默认 ironclad），但机制、数值、卡牌、遗物全部生效。
#
# 用法：右键 → 使用 PowerShell 运行
# 前置：只装 .NET 9 SDK 就够了（https://dotnet.microsoft.com/download/dotnet/9.0）

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Write-Host "=== 守烬人 Mod 精简版构建器 ===" -ForegroundColor Cyan
Write-Host "只装了 .NET SDK 也能跑，不需要 Godot。" -ForegroundColor DarkGray
Write-Host ""

$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $projectRoot

# ── 1. 定位游戏目录 ────────────────────────────────────────────
Write-Host "[1/4] 定位游戏目录..." -ForegroundColor Yellow

$candidates = @(
    "C:\Program Files (x86)\Steam\steamapps\common\Slay the Spire 2",
    "C:\Program Files\Steam\steamapps\common\Slay the Spire 2",
    "D:\SteamLibrary\steamapps\common\Slay the Spire 2",
    "E:\SteamLibrary\steamapps\common\Slay the Spire 2",
    "F:\SteamLibrary\steamapps\common\Slay the Spire 2",
    "G:\SteamLibrary\steamapps\common\Slay the Spire 2"
)

$gameDir = $null
foreach ($p in $candidates) { if (Test-Path $p) { $gameDir = $p; break } }
if (-not $gameDir) {
    $gameDir = (Read-Host "没找到游戏，请粘贴 Slay the Spire 2 的完整路径").Trim('"')
}
if (-not (Test-Path $gameDir)) { Write-Host "路径不存在：$gameDir" -ForegroundColor Red; exit 1 }
Write-Host "  $gameDir" -ForegroundColor Green

$dataDir = Join-Path $gameDir "data_sts2_windows_x86_64"
$install = Join-Path $gameDir "mods\Emberkeeper"

# ── 2. 检查环境 ────────────────────────────────────────────────
Write-Host "[2/4] 检查环境..." -ForegroundColor Yellow

$sdkOk = $false
try {
    $sdks = & dotnet --list-sdks 2>$null
    if ($sdks) { foreach ($s in $sdks) { if ($s -like "9.*") { $sdkOk = $true; break } } }
} catch { }

if (-not $sdkOk) {
    Write-Host ""
    Write-Host "  没检测到 .NET 9 SDK。" -ForegroundColor Red
    Write-Host "  这是唯一的硬性依赖，去这里装（选 SDK 不是 Runtime）：" -ForegroundColor Yellow
    Write-Host "  https://dotnet.microsoft.com/download/dotnet/9.0" -ForegroundColor Cyan
    Write-Host "  装完重跑本脚本即可。" -ForegroundColor Yellow
    exit 1
}
Write-Host "  .NET 9 SDK 就绪" -ForegroundColor Green

if (-not (Test-Path (Join-Path $dataDir "sts2.dll"))) {
    Write-Host "  找不到 $dataDir\sts2.dll，游戏目录可能不对" -ForegroundColor Red; exit 1
}
if (-not (Test-Path (Join-Path $gameDir "mods\BaseLib\BaseLib.dll"))) {
    Write-Host "  找不到 BaseLib.dll，请先运行 tools\install_baselib.ps1" -ForegroundColor Red; exit 1
}
Write-Host "  sts2.dll / BaseLib 已就位" -ForegroundColor Green

# ── 3. 编译（NO_PCK 模式） ──────────────────────────────────────
Write-Host "[3/4] 编译 Emberkeeper.dll（精简模式）..." -ForegroundColor Yellow

$props = @"
<Project>
  <PropertyGroup>
    <Sts2Dir>$gameDir</Sts2Dir>
  </PropertyGroup>
</Project>
"@
Set-Content -Path "local.props" -Value $props -Encoding UTF8

& dotnet build -c Release --nologo -p:EmberkeeperNoPck=true
if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "  编译失败，请往上翻看具体报错。" -ForegroundColor Red
    Write-Host "  常见原因：README 第六节列出的 3 个 API 签名与本地 sts2.dll 不一致。" -ForegroundColor Yellow
    Write-Host "  把报错贴给作者即可，几行就能改好。" -ForegroundColor Yellow
    exit 1
}

New-Item -ItemType Directory -Path $install -Force | Out-Null
$dll = Get-ChildItem -Path "bin" -Filter "Emberkeeper.dll" -Recurse | Select-Object -First 1
if (-not $dll) { Write-Host "  没找到编译产物 Emberkeeper.dll" -ForegroundColor Red; exit 1 }

Copy-Item $dll.FullName (Join-Path $install "Emberkeeper.dll") -Force
# 精简版用 has_pck:false 的 manifest
Copy-Item "Emberkeeper-NoPck.json" (Join-Path $install "Emberkeeper.json") -Force
Write-Host "  完成" -ForegroundColor Green

# ── 4. 收尾 ────────────────────────────────────────────────────
Write-Host "[4/4] 清理旧 pck 残留..." -ForegroundColor Yellow
if (Test-Path (Join-Path $install "Emberkeeper.pck")) {
    Remove-Item (Join-Path $install "Emberkeeper.pck") -Force
    Write-Host "  已删除残留的 Emberkeeper.pck（精简版不需要）" -ForegroundColor DarkGray
}

Write-Host ""
Write-Host "=== 安装完成 ===" -ForegroundColor Cyan
Write-Host "  $install"
Get-ChildItem $install | ForEach-Object { Write-Host "  $($_.Name)  ($([math]::Round($_.Length/1KB,1)) KB)" }

Write-Host ""
Write-Host "现在用 Play with Mods 启动游戏 → Mods 菜单勾选「守烬人 Emberkeeper」→ 重启。" -ForegroundColor Cyan
Write-Host ""
Write-Host "注意：精简版美术沿用原版角色，卡牌名会显示成 EMBERKEEPER-EMBER_STRIKE 这类原始 key。" -ForegroundColor DarkGray
Write-Host "      想换成守烬人专属立绘和中文卡名，之后装 Godot 4.5.1 跑 tools\build.ps1 导 pck 即可。" -ForegroundColor DarkGray
Write-Host ""
Read-Host "按回车键退出"
