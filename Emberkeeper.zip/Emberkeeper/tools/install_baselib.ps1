# BaseLib 一键安装脚本（Windows / PowerShell）
# 用法：右键 → 使用 PowerShell 运行
#      若提示"禁止运行脚本"，先以管理员打开 PowerShell 执行一次：
#      Set-ExecutionPolicy -Scope Process RemoteSigned

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$REPO = "Alchyr/BaseLib-StS2"

Write-Host "=== BaseLib 安装器 ===" -ForegroundColor Cyan

# ── 1. 定位游戏目录 ────────────────────────────────────────────
$defaultPaths = @(
    "C:\Program Files (x86)\Steam\steamapps\common\Slay the Spire 2",
    "C:\Program Files\Steam\steamapps\common\Slay the Spire 2",
    "D:\SteamLibrary\steamapps\common\Slay the Spire 2",
    "E:\SteamLibrary\steamapps\common\Slay the Spire 2"
)

$gameDir = $null
foreach ($p in $defaultPaths) {
    if (Test-Path $p) { $gameDir = $p; break }
}

if (-not $gameDir) {
    $gameDir = Read-Host "没找到游戏目录，请手动粘贴 Slay the Spire 2 的完整路径"
    $gameDir = $gameDir.Trim('"')
}

if (-not (Test-Path $gameDir)) {
    Write-Host "路径不存在：$gameDir" -ForegroundColor Red
    exit 1
}

Write-Host "游戏目录：$gameDir" -ForegroundColor Green

# ── 2. 查询 GitHub 最新版本 ─────────────────────────────────────
Write-Host "正在查询 BaseLib 最新版本..." -ForegroundColor Yellow

try {
    $release = Invoke-RestMethod `
        -Uri "https://api.github.com/repos/$REPO/releases/latest" `
        -Headers @{ "User-Agent" = "BaseLib-Installer" }
} catch {
    Write-Host "GitHub 访问失败（可能是网络问题）。" -ForegroundColor Red
    Write-Host "请手动下载：https://github.com/$REPO/releases" -ForegroundColor Yellow
    exit 1
}

$tag = $release.tag_name
Write-Host "最新版本：$tag" -ForegroundColor Green

# ── 3. 挑出要下的文件 ──────────────────────────────────────────
$assets = $release.assets

# 优先下 zip 包（一次搞定）
$zip = $assets | Where-Object { $_.name -like "*.zip" } | Select-Object -First 1

$modsDir  = Join-Path $gameDir "mods"
$baseDir  = Join-Path $modsDir  "BaseLib"
$tempDir  = Join-Path $env:TEMP  "baselib_dl"

if (Test-Path $tempDir) { Remove-Item $tempDir -Recurse -Force }
New-Item -ItemType Directory -Path $tempDir | Out-Null
New-Item -ItemType Directory -Path $baseDir -Force | Out-Null

if ($zip) {
    Write-Host "下载 $($zip.name) ..." -ForegroundColor Yellow
    $zipPath = Join-Path $tempDir $zip.name
    Invoke-WebRequest -Uri $zip.browser_download_url -OutFile $zipPath
    Expand-Archive -Path $zipPath -DestinationPath $tempDir -Force

    # 从解压结果里捞三个文件（可能在子目录）
    foreach ($ext in @("*.dll", "*.pck", "*.json")) {
        $found = Get-ChildItem -Path $tempDir -Filter $ext -Recurse |
                 Where-Object { $_.Name -like "BaseLib*" } |
                 Select-Object -First 1
        if ($found) {
            Copy-Item $found.FullName (Join-Path $baseDir $found.Name) -Force
            Write-Host "  ✓ $($found.Name)" -ForegroundColor Green
        }
    }
} else {
    # 没有 zip，就一个个下
    foreach ($ext in @(".dll", ".pck", ".json")) {
        $asset = $assets | Where-Object { $_.name -like "*BaseLib*$ext" } |
                 Select-Object -First 1
        if ($asset) {
            Write-Host "下载 $($asset.name) ..." -ForegroundColor Yellow
            Invoke-WebRequest -Uri $asset.browser_download_url `
                -OutFile (Join-Path $baseDir $asset.name)
            Write-Host "  ✓ $($asset.name)" -ForegroundColor Green
        } else {
            Write-Host "  ! 没找到 *BaseLib$ext" -ForegroundColor Yellow
        }
    }
}

# ── 4. 校验 ────────────────────────────────────────────────────
Write-Host ""
Write-Host "安装结果：$baseDir" -ForegroundColor Cyan
$files = Get-ChildItem $baseDir | Select-Object -ExpandProperty Name
if (-not $files) { $files = @() }
$files | ForEach-Object { Write-Host "  $_" }

$ok = ($files -like "*.dll").Count -gt 0 -and `
      ($files -like "*.pck").Count -gt 0 -and `
      ($files -like "*.json").Count -gt 0

if ($ok) {
    Write-Host ""
    Write-Host "BaseLib 三件套齐全！" -ForegroundColor Green
    Write-Host "下一步：用 Play with Mods 启动 → 主菜单 Mods → 勾选 BaseLib → 重启游戏" -ForegroundColor Cyan
} else {
    Write-Host ""
    Write-Host "文件不全，建议手动下载 $tag 解压到：" -ForegroundColor Red
    Write-Host "  https://github.com/$REPO/releases/tag/$tag" -ForegroundColor Yellow
    Write-Host "  目标目录：$baseDir" -ForegroundColor Yellow
}

Remove-Item $tempDir -Recurse -Force -ErrorAction SilentlyContinue
Write-Host ""
Read-Host "按回车键退出"
