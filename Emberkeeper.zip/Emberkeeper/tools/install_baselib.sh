#!/usr/bin/env bash
# BaseLib 一键安装脚本（macOS / Linux）
# 用法：chmod +x install_baselib.sh && ./install_baselib.sh

set -euo pipefail
REPO="Alchyr/BaseLib-StS2"

echo "=== BaseLib 安装器 ==="

# ── 1. 定位游戏目录 ────────────────────────────────────────────
if [[ "$(uname)" == "Darwin" ]]; then
    DEFAULT="$HOME/Library/Application Support/Steam/steamapps/common/Slay the Spire 2/SlayTheSpire2.app/Contents/MacOS"
else
    DEFAULT="$HOME/.steam/steam/steamapps/common/Slay the Spire 2"
fi

GAME_DIR=""
if [[ -d "$DEFAULT" ]]; then
    GAME_DIR="$DEFAULT"
else
    read -rp "没找到游戏目录，请粘贴 Slay the Spire 2 的路径（mac 请指到 Contents/MacOS）： " GAME_DIR
    GAME_DIR="${GAME_DIR%\"}"; GAME_DIR="${GAME_DIR#\"}"
fi

if [[ ! -d "$GAME_DIR" ]]; then
    echo "路径不存在：$GAME_DIR"; exit 1
fi
echo "游戏目录：$GAME_DIR"

# ── 2. 查最新版本 ──────────────────────────────────────────────
echo "正在查询 BaseLib 最新版本..."
if ! command -v jq >/dev/null 2>&1; then
    echo "需要 jq，请先安装：brew install jq  (或 sudo apt install jq)"; exit 1
fi

RELEASE=$(curl -fsSL -H "User-Agent: BaseLib-Installer" \
    "https://api.github.com/repos/$REPO/releases/latest") || {
    echo "GitHub 访问失败，请手动下载：https://github.com/$REPO/releases"; exit 1; }

TAG=$(echo "$RELEASE" | jq -r .tag_name)
echo "最新版本：$TAG"

MODS_DIR="$GAME_DIR/mods"
BASE_DIR="$MODS_DIR/BaseLib"
TMP_DIR=$(mktemp -d)
mkdir -p "$BASE_DIR"

# ── 3. 下载 ────────────────────────────────────────────────────
ZIP_URL=$(echo "$RELEASE" | jq -r '.assets[] | select(.name | endswith(".zip")) | .browser_download_url' | head -1)

if [[ -n "$ZIP_URL" && "$ZIP_URL" != "null" ]]; then
    echo "下载压缩包..."
    curl -fsSL -o "$TMP_DIR/baselib.zip" "$ZIP_URL"
    unzip -q -o "$TMP_DIR/baselib.zip" -d "$TMP_DIR"
    for ext in dll pck json; do
        f=$(find "$TMP_DIR" -iname "BaseLib*.$ext" | head -1)
        [[ -n "$f" ]] && cp "$f" "$BASE_DIR/" && echo "  ✓ $(basename "$f")"
    done
else
    for ext in dll pck json; do
        URL=$(echo "$RELEASE" | jq -r ".assets[] | select(.name | endswith(\".$ext\")) | .browser_download_url" | head -1)
        if [[ -n "$URL" && "$URL" != "null" ]]; then
            NAME=$(basename "$URL")
            echo "下载 $NAME ..."
            curl -fsSL -o "$BASE_DIR/$NAME" "$URL"
            echo "  ✓ $NAME"
        fi
    done
fi

rm -rf "$TMP_DIR"

# ── 4. 校验 ────────────────────────────────────────────────────
echo ""
echo "安装结果：$BASE_DIR"
ls -1 "$BASE_DIR" 2>/dev/null | sed 's/^/  /' || true

n_dll=$(find "$BASE_DIR" -maxdepth 1 -name "*.dll" 2>/dev/null | wc -l | tr -d ' ')
n_pck=$(find "$BASE_DIR" -maxdepth 1 -name "*.pck" 2>/dev/null | wc -l | tr -d ' ')
n_json=$(find "$BASE_DIR" -maxdepth 1 -name "*.json" 2>/dev/null | wc -l | tr -d ' ')

if [[ "$n_dll" -gt 0 && "$n_pck" -gt 0 && "$n_json" -gt 0 ]]; then
    echo ""
    echo "BaseLib 三件套齐全！"
    echo "下一步：用 Play with Mods 启动 → 主菜单 Mods → 勾选 BaseLib → 重启游戏"
else
    echo ""
    echo "文件不全，请手动从下面地址下载 $TAG 解压到 $BASE_DIR"
    echo "  https://github.com/$REPO/releases/tag/$TAG"
fi
