#!/usr/bin/env bash
# 守烬人 Mod —— 精简版构建（macOS / Linux）
#
# 只需要一个 dll，不需要 Godot、不需要导出 pck。
# 角色美术沿用原版（默认 ironclad），但机制、数值、卡牌、遗物全部生效。
#
# 用法：chmod +x build-simple.sh && ./build-simple.sh
# 前置：只装 .NET 9 SDK 就够了

set -uo pipefail

echo "=== 守烬人 Mod 精简版构建器 ==="
echo "只装了 .NET SDK 也能跑，不需要 Godot。"
echo ""

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT" || exit 1

# ── 1. 定位游戏目录 ────────────────────────────────────────────
echo "[1/4] 定位游戏目录..."

if [[ "$(uname)" == "Darwin" ]]; then
    GAME_DIR="$HOME/Library/Application Support/Steam/steamapps/common/Slay the Spire 2/SlayTheSpire2.app/Contents/MacOS"
else
    GAME_DIR="$HOME/.steam/steam/steamapps/common/Slay the Spire 2"
fi

if [[ ! -d "$GAME_DIR" ]]; then
    read -rp "没找到游戏，请粘贴路径（mac 指到 Contents/MacOS）： " GAME_DIR
    GAME_DIR="${GAME_DIR%\"}"; GAME_DIR="${GAME_DIR#\"}"
fi
[[ -d "$GAME_DIR" ]] || { echo "路径不存在：$GAME_DIR"; exit 1; }
echo "  $GAME_DIR"

DATA_DIR=$(find "$GAME_DIR" "$(dirname "$GAME_DIR")" -maxdepth 3 -type d -name "data_sts2_*" 2>/dev/null | head -1)
[[ -n "$DATA_DIR" ]] || { echo "找不到 data_sts2_* 目录"; exit 1; }
INSTALL="$GAME_DIR/mods/Emberkeeper"

# ── 2. 检查环境 ────────────────────────────────────────────────
echo "[2/4] 检查环境..."

if ! command -v dotnet >/dev/null 2>&1; then
    echo "  没装 dotnet。这是唯一的硬性依赖："
    echo "  https://dotnet.microsoft.com/download/dotnet/9.0 （选 SDK，不是 Runtime）"
    exit 1
fi
if ! dotnet --list-sdks 2>/dev/null | grep -q "^9\."; then
    echo "  没检测到 .NET 9 SDK。下载地址："
    echo "  https://dotnet.microsoft.com/download/dotnet/9.0"
    exit 1
fi
echo "  .NET 9 SDK 就绪"

[[ -f "$DATA_DIR/sts2.dll" ]] || { echo "找不到 sts2.dll：$DATA_DIR"; exit 1; }
[[ -f "$GAME_DIR/mods/BaseLib/BaseLib.dll" ]] || {
    echo "  找不到 BaseLib.dll，请先运行 tools/install_baselib.sh"; exit 1; }
echo "  sts2.dll / BaseLib 已就位"

# ── 3. 编译（NO_PCK 模式） ──────────────────────────────────────
echo "[3/4] 编译 Emberkeeper.dll（精简模式）..."

cat > local.props <<EOF
<Project>
  <PropertyGroup>
    <Sts2Dir>$GAME_DIR</Sts2Dir>
    <Sts2DataDir>$DATA_DIR</Sts2DataDir>
  </PropertyGroup>
</Project>
EOF

if ! dotnet build -c Release --nologo -p:EmberkeeperNoPck=true; then
    echo ""
    echo "  编译失败，请往上翻看具体报错。"
    echo "  常见原因：README 第六节列出的 3 个 API 签名与本地 sts2.dll 不一致。"
    exit 1
fi

mkdir -p "$INSTALL"
DLL=$(find bin -name "Emberkeeper.dll" 2>/dev/null | head -1)
[[ -n "$DLL" ]] || { echo "没找到编译产物 Emberkeeper.dll"; exit 1; }
cp "$DLL" "$INSTALL/Emberkeeper.dll"
cp Emberkeeper-NoPck.json "$INSTALL/Emberkeeper.json"
echo "  完成"

# ── 4. 收尾 ────────────────────────────────────────────────────
echo "[4/4] 清理旧 pck 残留..."
[[ -f "$INSTALL/Emberkeeper.pck" ]] && rm -f "$INSTALL/Emberkeeper.pck" && echo "  已删除残留的 Emberkeeper.pck"

echo ""
echo "=== 安装完成 ==="
echo "  $INSTALL"
ls -lh "$INSTALL" | tail -n +2 | awk '{print "  "$9"  ("$5")"}'

echo ""
echo "现在用 Play with Mods 启动游戏 → Mods 菜单勾选「守烬人 Emberkeeper」→ 重启。"
echo ""
echo "注意：精简版美术沿用原版角色，卡牌名会显示成 EMBERKEEPER-EMBER_STRIKE 这类原始 key。"
echo "      想换成专属立绘和中文卡名，之后装 Godot 4.5.1 跑 tools/build.sh 导 pck 即可。"
