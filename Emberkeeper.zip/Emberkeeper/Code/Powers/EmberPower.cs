using System.Threading.Tasks;
using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Creatures;
using MegaCrit.Sts2.Core.Entities.Powers;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.ValueProps;

namespace Emberkeeper.Code.Powers;

/// <summary>
/// 余烬（Ember）—— 守烬人的核心资源状态。
///
/// 规则：自己回合开始时，身上的余烬全部燃尽，等量转化为格挡。
/// 也就是说：这一回合打得越凶，攒的余烬越多，下回合开局就越耐打。
/// </summary>
public class EmberPower : CustomPowerModel
{
    // 增益
    public override PowerType Type => PowerType.Buff;

    // 可叠加（Counter）
    public override PowerStackType StackType => PowerStackType.Counter;

    // 图标：小图 64x64，大图 256x256，1:1 即可
    public override string? CustomPackedIconPath => "res://Emberkeeper/images/powers/ember.png";
    public override string? CustomBigIconPath => "res://Emberkeeper/images/powers/ember.png";

    /// <summary>
    /// 回合开始：把余烬烧成灰烬护甲。
    ///
    /// ⚠️ 本地化核对点：如果你的 sts2.dll 里回合开始钩子不叫 AfterTurnStart
    /// （可能是 BeforeTurnStart / AfterPlayerTurnStart），用 ilspycmd 反编译
    /// PowerModel 搜一下改个名即可，方法体不用动。
    /// </summary>
    public override async Task AfterTurnStart(PlayerChoiceContext choiceContext, Creature creature)
    {
        // 只处理自己的回合
        if (creature != Owner)
        {
            return;
        }

        int amount = Amount;
        if (amount <= 0)
        {
            return;
        }

        // 1) 等量格挡
        await CreatureCmd.GainBlock(Owner, amount, ValueProp.Move, null);

        // 2) 烧干净
        await PowerCmd.Remove(this);

        // 备选写法（某些 BaseLib 版本没有 Remove）：
        // await PowerCmd.Apply(choiceContext, Owner, -amount, Owner, null);
    }
}
