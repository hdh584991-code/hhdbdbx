using Godot;
using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Models.CardPools;
using MegaCrit.Sts2.Core.Models.RelicPools;
using MegaCrit.Sts2.Core.Models.PotionPools;

namespace Emberkeeper.Code.Characters.Pools;

/// <summary>
/// 守烬人的专属卡池。
/// 你后续所有卡牌都要写成 [Pool(typeof(EmberCardPool))] 才会进这个池子。
/// </summary>
public class EmberCardPool : CustomCardPoolModel
{
    // 卡池 ID，必须唯一，别和其他 mod 撞车
    public override string Title => "emberkeeper";

    // 描述文字里用的小能量图标（24x24）
    public override string? TextEnergyIconPath => "res://Emberkeeper/images/energy_ember.png";

    // tooltip 和卡牌左上角的大能量图标（74x74）
    public override string? BigEnergyIconPath => "res://Emberkeeper/images/energy_ember_big.png";

    // 卡池主题色（暗橙红：余烬）
    public override Color DeckEntryCardColor => new(0.85f, 0.35f, 0.12f);

    // 默认卡框的着色
    public override Color ShaderColor => new(0.85f, 0.35f, 0.12f);

    // 不是无色池
    public override bool IsColorless => false;
}

/// <summary>
/// 守烬人的专属遗物池。
/// </summary>
public class EmberRelicPool : CustomRelicPoolModel
{
    public override string? TextEnergyIconPath => "res://Emberkeeper/images/energy_ember.png";
    public override string? BigEnergyIconPath => "res://Emberkeeper/images/energy_ember_big.png";
}

/// <summary>
/// 守烬人的专属药水池。
/// </summary>
public class EmberPotionPool : CustomPotionPoolModel
{
    public override string? TextEnergyIconPath => "res://Emberkeeper/images/energy_ember.png";
    public override string? BigEnergyIconPath => "res://Emberkeeper/images/energy_ember_big.png";
}
