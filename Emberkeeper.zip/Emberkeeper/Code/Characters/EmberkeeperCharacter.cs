using System.Collections.Generic;
using Godot;
using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.Entities.Creatures;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.CardPools;
using MegaCrit.Sts2.Core.Models.PotionPools;
using MegaCrit.Sts2.Core.Models.RelicPools;
using Emberkeeper.Code.Cards;
using Emberkeeper.Code.Characters.Pools;
using Emberkeeper.Code.Relics;

namespace Emberkeeper.Code.Characters;

/// <summary>
/// 新可玩角色：守烬人（Emberkeeper）
///
/// 核心机制 —— 余烬（Ember）：
///   回合开始时，身上的余烬会全部燃尽，等量转化为格挡；
///   攻击牌在造成伤害的同时积攒余烬，所以"打得越狠，下回合越耐打"。
///
/// 继承 PlaceholderCharacterModel：缺少的资源会自动回退到原版角色（PlaceholderID），
/// 所以你现在没有立绘、没有 Spine 动画也能直接进游戏跑起来。
/// </summary>
public class EmberkeeperCharacter : PlaceholderCharacterModel
{
    // ────────────────────────── 基础设定 ──────────────────────────

    /// <summary>
    /// 缺资源时借用哪个原版角色的美术。
    /// 可选：ironclad / silent / defect / regent / necrobinder
    /// 想完全换成自己的立绘，就配合下面 CustomVisualPath 等路径一起替换。
    /// </summary>
    public override string PlaceholderID => "ironclad";

    // 角色名颜色（暗橙）
    public override Color NameColor => new(0.85f, 0.35f, 0.12f);

    // 能量图标描边颜色
    public override Color EnergyLabelOutlineColor => new(0.35f, 0.08f, 0.02f);

    // 地图上画画用的颜色
    public override Color MapDrawingColor => new(0.85f, 0.35f, 0.12f);

    // 性别：影响部分动态文本（他/她/它）
    public override CharacterGender Gender => CharacterGender.Neutral;

    // 初始血量
    public override int StartingHp => 75;

    // 初始金币（不写就是默认 99）
    public override int StartingGold => 99;

    // ────────────────────────── 场景 / 美术资源 ──────────────────────────
    //
    // 【关于 NO_PCK 开关】
    // 定义了 EMBERKEEPER_NO_PCK 编译常量时，下面所有 res:// 资源引用会被整段剔除，
    // 角色完全复用 PlaceholderID（默认 ironclad）的原版美术，mod 只需要一个 dll 就能跑，
    // 不需要 Godot、不需要导出 pck。
    //
    // 想启用完整美术，去掉这个编译常量 + 用 Godot 导出 pck 即可，代码不用改第二遍。

#if !EMBERKEEPER_NO_PCK

    // 战斗中的人物场景（结构见 README）
    public override string CustomVisualPath => "res://Emberkeeper/scenes/emberkeeper_character.tscn";

    // 能量表盘
    public override string CustomEnergyCounterPath => "res://Emberkeeper/scenes/emberkeeper_energy_counter.tscn";

    // 左上角小头像（图片）
    public override string CustomIconTexturePath => "res://Emberkeeper/images/char_select_emberkeeper.png";

    // 角色选择界面大图 + 锁定态
    public override string CustomCharacterSelectIconPath => "res://Emberkeeper/images/char_select_emberkeeper.png";
    public override string CustomCharacterSelectLockedIconPath => "res://Emberkeeper/images/char_select_emberkeeper_locked.png";

    // 角色选择界面背景（Control 场景）
    public override string CustomCharacterSelectBg => "res://Emberkeeper/scenes/emberkeeper_bg.tscn";

    // 商店里的立绘 / 篝火旁的立绘
    public override string CustomMerchantAnimPath => "res://Emberkeeper/scenes/emberkeeper_merchant.tscn";
    public override string CustomRestSiteAnimPath => "res://Emberkeeper/scenes/emberkeeper_rest_site.tscn";

#endif

    // 出牌拖尾特效（借用原版）
    // public override string CustomTrailPath => "res://scenes/vfx/card_trail_ironclad.tscn";

    // 过渡音效：这个不能删，先借用原版铁血战士的
    public override string CharacterTransitionSfx => "event:/sfx/ui/wipe_ironclad";

    // ────────────────────────── 池子绑定 ──────────────────────────

    public override CardPoolModel CardPool => ModelDb.CardPool<EmberCardPool>();
    public override RelicPoolModel RelicPool => ModelDb.RelicPool<EmberRelicPool>();
    public override PotionPoolModel PotionPool => ModelDb.PotionPool<EmberPotionPool>();

    // ────────────────────────── 初始卡组 ──────────────────────────
    // 想改数量直接增删下面几行。

    public override IEnumerable<CardModel> StartingDeck =>
    [
        ModelDb.Card<EmberStrike>(),
        ModelDb.Card<EmberStrike>(),
        ModelDb.Card<EmberStrike>(),
        ModelDb.Card<EmberStrike>(),
        ModelDb.Card<EmberStrike>(),
        ModelDb.Card<EmberDefend>(),
        ModelDb.Card<EmberDefend>(),
        ModelDb.Card<EmberDefend>(),
        ModelDb.Card<EmberDefend>(),
        ModelDb.Card<EmberDefend>(),
    ];

    // ────────────────────────── 初始遗物 ──────────────────────────

    public override IReadOnlyList<RelicModel> StartingRelics =>
    [
        ModelDb.Relic<EmberHeart>(),
    ];

    // ────────────────────────── 其它 ──────────────────────────

    // 攻击建筑师（Boss）时的打击特效列表
    public override List<string> GetArchitectAttackVfx() =>
    [
        "vfx/vfx_attack_blunt",
        "vfx/vfx_heavy_blunt",
        "vfx/vfx_attack_slash",
        "vfx/vfx_bloody_impact",
        "vfx/vfx_rock_shatter"
    ];
}
