using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Entities.Cards;

namespace Emberkeeper.Code.Cards;

/// <summary>
/// 守烬人所有卡牌的基类：统一把卡图指到 images/cards/{类名}.png。
/// 你后面加新卡时继承它就行，不用每张卡再写一遍 PortraitPath。
/// </summary>
public abstract class EmberCardModel : CustomCardModel
{
#if !EMBERKEEPER_NO_PCK
    public override string PortraitPath => $"res://Emberkeeper/images/cards/{GetType().Name}.png";
#endif

    protected EmberCardModel(
        int energyCost,
        CardType type,
        CardRarity rarity,
        TargetType targetType,
        bool shouldShowInCardLibrary)
        : base(energyCost, type, rarity, targetType, shouldShowInCardLibrary)
    {
    }
}
